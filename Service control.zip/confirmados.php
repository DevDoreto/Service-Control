<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="rafaStyle.css">
	<link rel="stylesheet" href="style1.css">
	<title>Confirmação</title>

	<?php include_once('RodaPe.php');?>
</head>
		<?php  
	session_start();
	if (isset($_SESSION['nome']) == false || isset($_SESSION['poder']) == false) 
	{
			session_unset();
			session_destroy();
			die(header('location:validar.php'));	
	}
	?>
<body class="body">

	<div class="menuServ">
		<a href="servico.php" class="linkServ">Aguardando orçamento</a>
		<a href="confirmados.php" class="linkServ">Aguardando Confirmação</a>
		<a href="manutencao.php" class="linkServ">Aguardando Manutenção</a>
	</div>

	<?php 
	REQUIRE_ONCE('conect.php');	
	$validar = 0;
	$sql= "SELECT * FROM produto, servico, cliente WHERE produto.estatos = 'A' AND produto.idProduto = servico.idProduto 
	AND produto.idCliente = cliente.idCliente  ";
	$pegar = mysqli_query($ir, $sql);

	while ($registro = mysqli_fetch_array($pegar)){
		$id = $registro['idProduto'];
		$aco = $registro['acompProduto'];
		$modelo = $registro['modeloProduto'];
		$desc = $registro['descProduto'];
		$data = $registro['entrada'];
		$dia = date('d-m-Y', strtotime($data));
		$hora = date('h:i:s', strtotime($data));
		$orca = $registro['orcamento'];
		$pecas = $registro['pecas'];
		$previsao = $registro['previsao'];
		$tec = $registro['tecnico'];
		$nomeCliente = $registro['nomeCliente'];
		$tellCliente = $registro['telCliente'];
		$tellCliente2 = $registro['tel2Cliente'];
		$endereco = $registro['endCliente'];

		$validar = 2;
	
?>
<main class="main">

<section class="section">	



		<div class="div">
				<div class="divLabel">
					<label class="labelCC label">Modelo: </label>
					<label class="labelCCresp"><?php echo $modelo;  ?></label>
				</div>
				<div class="divLabel">
					<label class="labelCC label">Acompanhamento do Produto:</label>
					<label class="labelCCresp"><?php echo $aco; ?></label>
				</div>
				<div class="divLabel">
					<label class="labelCC label">Data de entrada:</label>
					<label class="labelCCresp"><?php echo $dia;  ?></label>
				</div>
				<div class="divLabel">
					<label class="labelCC label">Horas:</label> 
					<label class="labelCCresp "><?php echo $hora; ?></label>
				</div>
				<div class="divLabel">
					<label class="labelCC label">Descrição:</label> 
					<label class="labelCCresp "><?php echo $desc; ?></label>
				</div>
				<div class="divLabel">
					<label class="labelCC label">Orçamento R$:</label> 
					<label class="labelCCresp "><?php echo $orca; ?></label>
				</div>
				<div class="divLabel">
					<label class="labelCC label">Peças:</label> 
					<label class="labelCCresp "><?php echo $pecas; ?></label>
				</div>
				<div class="divLabel">
					<label class="labelCC label">Previsão:</label> 
					<label class="labelCCresp "><?php echo $previsao; ?></label>
				</div>
				<div class="divLabel">
					<label class="labelCC label">Tecnico:</label> 
					<label class="labelCCresp "><?php echo $tec; ?></label>
				</div>
				<div class="divLabel">
					<label class="labelCC label">Nome do Cliente:</label> 
					<label class="labelCCresp "><?php echo $nomeCliente; ?></label>
				</div>
				<div class="divLabel">
					<label class="labelCC label">Telefone 1:</label> 
					<label class="labelCCresp "><?php echo $tellCliente; ?></label>
				</div>
				<div class="divLabel">
					<label class="labelCC label">Telefone 2:</label> 
					<label class="labelCCresp "><?php echo $tellCliente2; ?></label>
				</div>
				<div class="divLabel">
					<label class="labelCC label">Endereço:</label> 
					<label class="labelCCresp "><?php echo $endereco; ?></label>
				</div>
				
		</div>


<form action="confirmar.php" method="post">
	<input type="hidden" name="IDproduto" value="<?php echo $id ?>">
	<input type="submit" name="" value="Aceito o Orçamento" class="btn">
</form>

</section>
</main>
<?php 

}
 ?>
	

	<?php 
	if ($validar == 0) {
		?>

		<div class="boxAlert">
			<h1 class="alert">NÃO EXISTE REGISTROS</h1>
			<a href="index.php"><button class="btn">VOLTAR PARA O INICIO</button></a>
		</div>

		<?php
	}
?>

</body>
</html>