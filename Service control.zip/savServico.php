<?php  
error_reporting(0);
		session_start();
	if (isset($_SESSION['nome']) == false || isset($_SESSION['poder']) == false) 
	{
			session_unset();
			session_destroy();
			die(header('location:validar.php'));	
	} 
	REQUIRE_ONCE('criptografia.php');
	date_default_timezone_set('America/Sao_Paulo');

	$rep = $_POST['rep'];
	$id = descrip($_POST['pass']);
	
	$n =1;

	while ($n <= $rep) {
	
	if ($_POST["tab$n"] != '') {
		$quant .= $_POST["tab$n"].' ';
		$vezes = $_POST["tab$n"];
		$desc .= $_POST["des$n"].'/';
		$preco .= $_POST["pre$n"].' '; 
	}
	$valor1 =  $_POST["pre$n"];
	if ($quant != '') {
		$valor = $valor + $valor1 * $vezes;
	}
	$n++;
	
	}
	



	$tecnico = $_SESSION['nome'];
	$dias = $_POST['dias'];
	$orcamento = $valor ;
	$relatorio = $_POST['relatorio'];
	$day = date("Y-m-d H:m:s"); 
	$dia = date("d/m/Y");
	$horas = date("H:i");


	REQUIRE('conect.php');
	$sql = "INSERT INTO servico (idProduto, relatorio, tecnico, pecas, previsao, entrada, orcamento) VALUES 
	('$id','$relatorio', '$tecnico' , '$pecas' , '$dias' , '$day' ,'$orcamento') ";					
	mysqli_query($ir, $sql);
	$sql =  "UPDATE produto SET estatos = 'A' WHERE idProduto  = '$id' ";
	mysqli_query($ir, $sql);


?>    

<script>  window.alert("Confirmado o cadastro do orçamento!"); window.print();</script>

	<?php 
	include('impresao\index.php');

	//header("Refresh:0.2; url=servico.php");



?>