<?php  

  	session_start();
	if (isset($_SESSION['nome']) == false || isset($_SESSION['poder']) == false) 
	{
	session_unset();
	session_destroy();
			die(header('location:validar.php'));	
	}  
	
	

 REQUIRE_ONCE('conect.php');

 $id = $_POST['ID'];
 $estatos = $_POST['estatos'];

if ($estatos == 1) {

	$sql = "UPDATE funcionarios SET estatos = 0 WHERE idFuncionario = '$id' ";
  	mysqli_query($ir, $sql);
?>
	<script> window.alert("Conta Desativada!"); </script>
<?php 
	header("Refresh:0.5; url=cadastroFuncionarios.php");
 

}
elseif ($estatos == 0) {

	$sql = "UPDATE funcionarios SET estatos = 1 WHERE idFuncionario = '$id' ";
  	mysqli_query($ir, $sql);
	?>
	<script> window.alert("Conta Reativada"); </script>
	<?php 
	header("Refresh:0.5; url=cadastroFuncionarios.php");	
}
else{
	die('ERROR');
}


