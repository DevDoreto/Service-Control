<?php
//formato da criptografia
function gerar ($tamanho){
    $chars = "aeiouAEIOU0123456789";
    $var_size = strlen($chars);
    $random = '';
    for( $x = 0; $x < $tamanho; $x++ ) {
        $random_str= $chars[ rand( 0, $var_size - 1 ) ];  
        $random .= $random_str;
    }
    return $random; 
}
// criptografar
function crip($nome){
$quantNome = strlen($nome);
$cr = '';
for ($i=0; $i < $quantNome; $i++) { 
    $cripto = $nome[$i];
    $cr .= $cripto.gerar(2);    
}   
    $name = base64_encode($cr);
    return $name;
}
// descriptografar
function descrip($criptografia) {
$cr = base64_decode($criptografia);
$quantidade = strlen($cr);
$parametro = 3;
//$parametro = $parametro+1;
$xd = 0;
$renome = '';
    while ($quantidade > $xd) {
        $renome .= $cr[$xd];
        $xd = $xd+$parametro;
    }
    return $renome;
}
?>