<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="style1.css">
	<title>Login</title>
	<?php 
		session_start();
	if (isset($_SESSION['nome']) == true || isset($_SESSION['poder']) == true) {
		header('location:lista.php');
	}	
	?>

</head>
<body>

	<div class="formLog">

	<h1 class="h1Log">Login</h1>

	<form action="validar.php" method="post">
	
	<input type="name" class="inpLog" name="login" placeholder="Usuário" autocomplete="off" required>
	
	<input type="password" class="inpLog" name="senha" placeholder="Senha" required>
	<br>
	<input type="submit" class="btnLog" value="Enviar">

	</div>

	</form>
</body>
</html>
