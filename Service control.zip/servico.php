<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="rafaStyle.css">
	<link rel="stylesheet" href="style1.css">
	<title>Serviços</title>
</head>

<?php
		session_start();
	if (isset($_SESSION['nome']) == false || isset($_SESSION['poder']) == false) 
	{
			session_unset();
			session_destroy();
			die(header('location:validar.php'));	
	}  
	include_once('RodaPe.php');
	REQUIRE_ONCE('criptografia.php');
	REQUIRE_ONCE('conect.php');
	?>
	
<body class="body">
	<div class="menuServ">
		<a href="servico.php" class="linkServ">Aguardando orçamento</a>
		<a href="confirmados.php" class="linkServ">Aguardando Confirmação</a>
		<a href="manutencao.php" class="linkServ">Aguardando Manutenção</a>
	</div>
	<?php 
	$validar = 0;
	$sql= "SELECT * FROM produto where estatos = 'E' ";
	$pegar = mysqli_query($ir, $sql);
	$validar = 0;

	while ($registro = mysqli_fetch_array($pegar)){
		$id = $registro['idProduto'];
		$aco = $registro['acompProduto'];
		$modelo = $registro['modeloProduto'];
		$desc = $registro['descProduto'];
		$data = $registro['entradaProduto'];
		$data = date('d-m-Y', strtotime($data));
		$id = crip($id);
		$validar = 1;
	 ?>
	<main class="main">
		<section class="section">
			<div class="div">
			<label class="label">Modelo: <?php echo $modelo ?></label>
			<label class="label">Acompanhamento: <?php echo $aco; ?> </label>
			<label class="label">Data de entrada: <?php echo $data; ?> </label>
			<label class="label">Descrição: <?php echo $desc;  ?></label>

			<form action="cadservico.php" method="get" class="form">
				<input type="hidden" name="produto" value="<?php echo $id ?>" class="input">
				<input type="submit" name="" value="Analisar" class="input">
			</form>
			</div>
		</section>
	</main>

<?php } ?>

<?php 
	if ($validar == 0) {
		?>

		<div class="boxAlert">
			<h1 class="alert">NÃO EXISTE REGISTROS</h1>
			<a href="index.php"><button class="btn">VOLTAR PARA O INICIO</button></a>
		</div>

		<?php
	}
?>
</body>
</html>