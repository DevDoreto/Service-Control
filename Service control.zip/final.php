<?php 
 
	session_start();
	if (isset($_SESSION['nome']) == false || isset($_SESSION['poder']) == false) 
	{
			session_unset();
			session_destroy();
			die(header('location:validar.php'));	
	}

	REQUIRE_ONCE('conect.php');

	$id = $_POST['IDproduto'];
	$sql= "UPDATE produto SET estatos = 'F' WHERE produto.idProduto = '$id' ";
	mysqli_query($ir, $sql);
	$sql = "INSERT FROM final () "
?>
<script> window.alert("Serviço Finalizado");</script>
<?php header("Refresh:0.5; url=manutencao.php"); ?>
