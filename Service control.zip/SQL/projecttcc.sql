-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 01-Maio-2023 às 22:54
-- Versão do servidor: 10.4.27-MariaDB
-- versão do PHP: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `projecttcc`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente`
--

CREATE TABLE `cliente` (
  `idCliente` int(11) NOT NULL,
  `nomeCliente` varchar(30) NOT NULL,
  `emailCliente` varchar(40) DEFAULT NULL,
  `telCliente` varchar(15) NOT NULL,
  `tel2Cliente` varchar(15) DEFAULT NULL,
  `cpfCliente` varchar(17) NOT NULL,
  `endCliente` varchar(50) NOT NULL,
  `cepCliente` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `cliente`
--

INSERT INTO `cliente` (`idCliente`, `nomeCliente`, `emailCliente`, `telCliente`, `tel2Cliente`, `cpfCliente`, `endCliente`, `cepCliente`) VALUES
(1, 'richard', 'richard@gmail.com', '(11) 23123-1232', '(12) 31231-2312', '12312312312', 'Bairro: dawda, Rua: wdadwad, Numero: asdawd', '12312-312');

-- --------------------------------------------------------

--
-- Estrutura da tabela `final`
--

CREATE TABLE `final` (
  `idProduto` int(11) NOT NULL,
  `idFinal` int(11) NOT NULL,
  `nomeRetira` varchar(100) NOT NULL,
  `dataSaida` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `funcionarios`
--

CREATE TABLE `funcionarios` (
  `idFuncionario` int(11) NOT NULL,
  `poder` char(1) NOT NULL,
  `estatos` int(1) NOT NULL,
  `primeiroNome` varchar(100) NOT NULL,
  `login` varchar(100) NOT NULL,
  `senha` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Extraindo dados da tabela `funcionarios`
--

INSERT INTO `funcionarios` (`idFuncionario`, `poder`, `estatos`, `primeiroNome`, `login`, `senha`) VALUES
(1, 'D', 1, 'Richard', 'richard', '123');

-- --------------------------------------------------------

--
-- Estrutura da tabela `produto`
--

CREATE TABLE `produto` (
  `idProduto` int(11) NOT NULL,
  `descProduto` varchar(250) DEFAULT NULL,
  `acompProduto` varchar(200) DEFAULT NULL,
  `entradaProduto` datetime NOT NULL,
  `idCliente` int(11) NOT NULL,
  `modeloProduto` varchar(20) NOT NULL,
  `estatos` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `produto`
--

INSERT INTO `produto` (`idProduto`, `descProduto`, `acompProduto`, `entradaProduto`, `idCliente`, `modeloProduto`, `estatos`) VALUES
(4, 'Bateria, Tela', 'Carregador e Fone', '2023-04-22 12:02:32', 1, 'S10 pro', 'X'),
(5, 'Bateria, Tela', 'Carregador e Fone', '2023-04-22 12:03:04', 1, 'S10 pro', 'A'),
(6, 'Bateria, Tela', 'Carregador e Fone', '2023-04-22 12:03:18', 1, 'S10 pro', 'A'),
(8, 'Bateria, Tela', 'Carregador e Fone', '2023-04-22 12:14:10', 1, 'S10 pro', 'E'),
(9, 'Bateria, Tela', 'Carregador e Fone', '2023-04-22 12:16:07', 1, 'S10 pro', 'E'),
(10, 'Bateria, Tela', 'Chip e carregador', '2023-04-26 05:05:28', 1, 'nokia', 'F');

-- --------------------------------------------------------

--
-- Estrutura da tabela `servico`
--

CREATE TABLE `servico` (
  `idServico` int(11) NOT NULL,
  `orcamento` float NOT NULL,
  `entrada` datetime NOT NULL,
  `idProduto` int(11) NOT NULL,
  `relatorio` varchar(250) NOT NULL,
  `tecnico` varchar(100) NOT NULL,
  `pecas` varchar(250) NOT NULL,
  `previsao` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `servico`
--

INSERT INTO `servico` (`idServico`, `orcamento`, `entrada`, `idProduto`, `relatorio`, `tecnico`, `pecas`, `previsao`) VALUES
(1, 400, '2023-04-22 17:04:22', 6, 'problema por sujeira', 'Richard', 'bateria ', 1),
(2, 400, '2023-04-22 17:04:54', 6, 'problema por sujeira', 'Richard', 'bateria ', 1),
(3, 540, '2023-04-26 17:04:57', 10, 'qweq', 'Richard', 'bateria tela ', 1);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`idCliente`),
  ADD UNIQUE KEY `nome` (`nomeCliente`),
  ADD UNIQUE KEY `cpf` (`cpfCliente`);

--
-- Índices para tabela `final`
--
ALTER TABLE `final`
  ADD PRIMARY KEY (`idFinal`),
  ADD KEY `fk_idProdutoF` (`idProduto`);

--
-- Índices para tabela `funcionarios`
--
ALTER TABLE `funcionarios`
  ADD PRIMARY KEY (`idFuncionario`);

--
-- Índices para tabela `produto`
--
ALTER TABLE `produto`
  ADD PRIMARY KEY (`idProduto`),
  ADD KEY `fk_idCliente` (`idCliente`);

--
-- Índices para tabela `servico`
--
ALTER TABLE `servico`
  ADD PRIMARY KEY (`idServico`),
  ADD KEY `fk_idProduto` (`idProduto`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `cliente`
--
ALTER TABLE `cliente`
  MODIFY `idCliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `final`
--
ALTER TABLE `final`
  MODIFY `idFinal` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `funcionarios`
--
ALTER TABLE `funcionarios`
  MODIFY `idFuncionario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `produto`
--
ALTER TABLE `produto`
  MODIFY `idProduto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de tabela `servico`
--
ALTER TABLE `servico`
  MODIFY `idServico` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `final`
--
ALTER TABLE `final`
  ADD CONSTRAINT `fk_idProdutoF` FOREIGN KEY (`idProduto`) REFERENCES `produto` (`idProduto`);

--
-- Limitadores para a tabela `produto`
--
ALTER TABLE `produto`
  ADD CONSTRAINT `fk_idCliente` FOREIGN KEY (`idCliente`) REFERENCES `cliente` (`idCliente`);

--
-- Limitadores para a tabela `servico`
--
ALTER TABLE `servico`
  ADD CONSTRAINT `fk_idProduto` FOREIGN KEY (`idProduto`) REFERENCES `produto` (`idProduto`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
