<?php 

		  
	session_start();
	if (isset($_SESSION['nome']) == false || isset($_SESSION['poder']) == false) 
	{
			session_unset();
			session_destroy();
			die(header('location:validar.php'));	
	}

	REQUIRE_ONCE('conect.php');

	$id = $_POST['IDproduto'];
	$sql= "UPDATE produto SET estatos = 'M' WHERE produto.idProduto = '$id' ";
	mysqli_query($ir, $sql);
?>
<script> window.alert("Confirmado a Avaliação");</script>
<?php header("Refresh:0.5; url=confirmados.php"); ?>
