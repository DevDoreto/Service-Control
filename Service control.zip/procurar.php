<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Editar Cliente</title>
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
	<link rel="stylesheet" href="rafaStyle.css">
	<link rel="stylesheet" href="style1.css">
	
</head>
<?php
		session_start();
	if (isset($_SESSION['nome']) == false || isset($_SESSION['poder']) == false) 
	{
			session_unset();
			session_destroy();
			die(header('location:validar.php'));	
	}  ?>
<body class="body">
<?php include_once('RodaPe.php');?>
<?php
REQUIRE_ONCE('conect.php');
$pesquisa = $_POST['cpf'];

	if ($pesquisa != null){
	
	$sql= "SELECT * FROM cliente where cpfCliente  = '$pesquisa'";
	$pegar = mysqli_query($ir, $sql);



	while ($registro = mysqli_fetch_array($pegar)) { 
	$nome = $registro["nomeCliente"];
	$email = $registro["emailCliente"];
	$tell1 = $registro["telCliente"];
	$tell2 = $registro["tel2Cliente"];
	$cpf = $registro["cpfCliente"];
	$endereco = $registro["endCliente"];
	$cep = $registro["cepCliente"];


  ?>

  <main class="main">
	<section class="section">
			<form method="post" action="atualizar.php" class="form">
			<div class="div">
				<label for="nome" class="label">nome:</label>
				<input type="text" name="nome" value="<?php echo $nome; ?>" class="input">
			</div>
			<div class="div">
				<label for="email" class="label">Email:</label>
				<input type="email" name="email" value="<?php echo $email ; ?>" class="input">
			</div>
			<div class="div">
				<label for="tell1" class="label">Telefone:</label>
				<input type="text" name="tell1" onkeypress="$(this).mask('(00) 00000-0000')" value="<?php echo $tell1 ; ?>" class="input">
			</div>
			<div class="div">
				<label for="tell2" class="label">Telefone 2:</label>
				<input type="text" name="tell2" onkeypress="$(this).mask('(00) 00000-0000')" value="<?php echo $tell2 ; ?>" class="input">
			</div>
			<div class="div">
				<label for="cpf" class="label">Cpf:</label>
				<input type="text" name="cpf" onkeypress="$(this).mask('000.000.000-00');" value="<?php echo $cpf ;?>" class="input">
			</div>
			<div class="div">
				<label for="endereco" class="label">Endereço:</label>
				<input type="text" name="endereco" value="<?php echo $endereco ; ?>" class="input">
			</div>
			<div class="div">
				<label for="cep" class="label">Cep:</label>
				<input type="text" name="cep" onkeypress="$(this).mask('00000-000');" value="<?php echo $cep ; ?>" class="input">
			</div>
			<div class="div">
				<input type="submit" value="Atualizar" class="btn">
			</div>
	</section>
  </main>
<div><input type="hidden" value="<?php echo $id ; ?>"></div>

</form>
<?php }}else {
	echo "Error";
} ?>

</body>
</html>