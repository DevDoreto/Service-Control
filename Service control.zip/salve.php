<?php  

  	session_start();
	if (isset($_SESSION['nome']) == false || isset($_SESSION['poder']) == false) 
	{
	session_unset();
	session_destroy();
			die(header('location:validar.php'));	
	}  
	
	
REQUIRE_ONCE('conect.php');

$nome= addslashes(trim($_POST['nome']));
$login = addslashes(trim($_POST['login']));
$senha = addslashes(trim($_POST['senha']));
$poder = addslashes(trim($_POST['poder']));

	if ($_POST['nome'] != '' && $_POST['login'] != '' && $_POST['senha'] != '' && $_POST['poder'] != '') {

		$nome= addslashes(trim($_POST['nome']));
		$login = addslashes(trim($_POST['login']));
		$senha = addslashes(trim($_POST['senha']));
		$poder = addslashes(trim($_POST['poder']));

		$sql2 = "SELECT COUNT(*) AS total FROM funcionarios WHERE primeiroNome = '$nome'";
		$resultado = mysqli_query($ir , $sql2);
		
		$verificar = mysqli_fetch_array($resultado);
		if ($verificar['total'] >= 1) {
			?>
			<script >window.alert("FUNCIONARIO JA CADASTRADO ");</script>
			<!-- <?php echo $verificar['total']; ?> -->
			<?php
			header('Refresh:0.5 url=cadastroFuncionarios.php');
		}else {
		
		$sql = "INSERT INTO funcionarios (poder, estatos, primeiroNome, login, senha) VALUES ('$poder', 1, '$nome', '$login', '$senha') ";
		mysqli_query($ir, $sql);
		?>
		<script >window.alert("Cadastro Efetuado com Sucesso!");</script>
		<?php
		header('Refresh:0.5 url=cadastroFuncionarios.php');
	}
	
	}

	else{
		?>
		<script >window.alert("ERRO");</script>
		<?php  
		header('Refresh:0.5: url=cadastroFuncionarios.php');
	}

?>
