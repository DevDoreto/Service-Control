
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Cadastro Clientes</title>
	<style>
		*{
			font-family: Arial, Helvetica, sans-serif;
			font-size: large;
		}
	</style>
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
	<link rel="stylesheet" href="rafaStyle.css">
	<link rel="stylesheet" href="style1.css">

<?php include_once('RodaPe.php');?>
    	<?php 
		
		session_start();
	if (isset($_SESSION['nome']) == false || isset($_SESSION['poder']) == false) 
	{
	session_unset();
	session_destroy();
	die(header('location:validar.php'));	
	}  
	

    	error_reporting(0);
	REQUIRE_ONCE('conect.php');

	if ($_POST['cpf'] == '') {}

	else { ?>
	<script type="text/javascript">
	window.alert("Cadastro Efetuado com Sucesso!");
	</script>
	<?php 
	$nome = $_POST['name'];
	$email = $_POST['email'];
	$tell1 = $_POST['tellCliente1'];
	$tell2 = $_POST['tellCliente2'];
	$cpf = $_POST['cpf'];
	$cep = $_POST['cep'];
	$endereco ='Bairro: ' .$_POST['bairro'].', Rua: '.$_POST['rua'].', Numero: '.$_POST['numero'];
	$cpf = str_replace("." , "" , $cpf );
	$cpf = str_replace("-","",$cpf);

		$sql =  "INSERT INTO cliente (nomeCliente , emailCliente , telCliente , tel2Cliente , cpfCliente , endCliente, cepCliente) 
		VALUES ('$nome' , '$email' , '$tell1' , '$tell2' , '$cpf' , '$endereco' , '$cep')";
		mysqli_query($ir, $sql);
}
	?>
</head>


<body class="body">


<main class="main">
	<section class="section">
		<label class="titulo">CADASTRO</label>
		<form action="#" method="post" class="form">
	
			<div class="div">
				<div class="divInput">
					<input type="text"  class="input inputS" name="name" required placeholder=" " autocomplete="false" >
					<label for="name" class="placeholder">Digite seu Nome</label>
				</div>
				<div class="divInput">
					<input type="email" class="input inputS" name="email" placeholder=" " autocomplete="false">
					<label for="email" class="placeholder">Digite seu Email</label>
				</div>
				<div class="divInput">
					<input type="tell"  class="input inputS" name="tellCliente1" onkeypress="$(this).mask('(00) 00000-0000')" placeholder=" " autocomplete="false">
					<label for="tellCliente1" class="placeholder">Digite o numero do seu Telefone</label>
				</div>
				<div class="divInput">
					<input type="tell"  class="input inputS" name="tellCliente2" onkeypress="$(this).mask('(00) 00000-0000')" placeholder=" " autocomplete="false">
					<label for="tellCliente2" class="placeholder">Digite o numero do seu Telefone</label>
				</div>
				<div class="divInput">
					<input type="text"  class="input inputS" name="cpf" placeholder=" " required onkeypress="$(this).mask('000.000.000-00');" autocomplete="false">
					<label for="cpf" class="placeholder">Digite seu Cpf</label>
				</div>
				<div class="divInput">
					<input type="text"  class="input inputS" name="cep" placeholder=" " onkeypress="$(this).mask('00000-000');" autocomplete="false">
					<label for="cep" class="placeholder">Digite seu CEP</label>
				</div>
				<div class="divInput">
					<input type="text"  class="input inputS" name="bairro" required placeholder=" " autocomplete="false">
					<label for="bairro" class="placeholder">Digite seu Bairro</label>
				</div>
				<div class="divInput">
					<input type="text"  class="input inputS" name="rua" required placeholder=" " autocomplete="false">
					<label for="rua" class="placeholder">Digite o nome da sua rua</label>
				</div>
				<div class="divInput">
					<input type="text" class="input inputS"  name="numero" required placeholder=" " autocomplete="false">
					<label for="numero" class="placeholder">Digite o numero da sua casa</label>
				</div>
			
	
			<input type="submit" class="btn" value="SALVAR"><br><br>
		</form>
	</section>
	
	<section class="section">
		<label class="titulo"> Atualizar Cliente </label>
		<form action="#" method="get" class="form">
			<div class="div">
				<input type="text" class="input" name="info" placeholder="Digite o CPF da pessoa" required>
				<input type="submit" value="🔍" class="btn">
			</div>
		</form>
	</section>
</main>





<?php
	

	$info = $_GET['info'];
	if ($info != null) {

	$sql="SELECT nomeCliente, telCliente, cpfCliente, cepCliente FROM cliente where cpfCliente LIKE '%$info%' OR nomeCliente LIKE '%$info%' ";
	$pegar = mysqli_query($ir, $sql);



	while ($registro = mysqli_fetch_array($pegar)) { 
	$nome = $registro["nomeCliente"];
	$telefone = $registro["telCliente"];
	$cpf = $registro["cpfCliente"];
	$cep = $registro["cepCliente"];

	?>

	<main class="main">
			<section class="section">
				<form method="post" action="procurar.php" class="form">
					<div class="div">
				<div class="divLabel">
					<label class="labelCC label">Nome: </label>
					<label class="labelCCresp"><?php echo $nome;  ?></label>
				</div>
				<div class="divLabel">
					<label class="labelCC label">Telefone:</label>
					<label class="labelCCresp"><?php echo $telefone; ?></label>
				</div>
				<div class="divLabel">
					<label class="labelCC label">Cpf:</label>
					<label class="labelCCresp"><?php echo $cpf;  ?></label>
				</div>
				<div class="divLabel">
					<label class="labelCC label">Cep:</label> 
					<label class="labelCCresp "><?php echo $cep; ?></label>
				</div>
				<input type="submit" value="ATUALIZAR" class="btn">
				<input type="hidden" name="cpf" value="<?php echo $cpf;  ?>">
					</div>
					</form>
			</section>
		</main>

	<?php  
}}
?>

	
	
</body>
</html>