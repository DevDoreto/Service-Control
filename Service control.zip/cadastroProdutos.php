<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="rafaStyle.css">
	<link rel="stylesheet" href="style1.css">
	<title>Cadastro de Produtos</title>
	<?php  
	
	session_start();
	if (isset($_SESSION['nome']) == false || isset($_SESSION['poder']) == false) 
	{
	session_unset();
	session_destroy();
	die(header('location:validar.php'));	
	}  
	REQUIRE_ONCE('conect.php');
	REQUIRE('funcoes/funcoes.php');
	REQUIRE_ONCE('criptografia.php');
	$ID = descrip($_GET['comanda']);
	include('RodaPe.php');



?>
	
</head>
<body class="body">
	<main class="main">
		<section class="section">
			<form action="cadpro.php" method="post" class="form">
				<div class="div">
					<label for="modelo" class="label">Modelo</label>
					<input type="text" name="modelo" placeholder="MODELO DO PRODUTO" required class="input">
				</div>

					<div class="div">
						<label for="acompProduto" class="label">Acompanhamentos</label>
						<input type="text" name="acompProduto" placeholder="OBJETOS JUNTOS AO PRODUTO" class="input">
					</div>
					<div class="div">
						<label class="label">POSSIVEIS PROBLEMAS</label>
					</div>
					<div class="divCheckbox">
					<div class="div divCB">
						<label for="bateria" class="label">Bateria </label>
						<input type="checkbox" name="bateria" value="Bateria" class="cbInp">
					</div>
					<div class="div">
						<label for="tela" class="label">Tela </label>
						<input type="checkbox" name="tela" value="Tela" class="cbInp">
					</div>
					<div class="div">
						<label for="carregamento" class="label">Carregamento </label>
						<input type="checkbox" name="carregamento" value="Carregamento" class="cbInp">
					</div>
	
					</div>


				<div class="div">
					<label for="outros" class="label">Outros</label>
					<input type="text" name="outros" placeholder="OUTROS PROBLEMAS...." class="input">
				</div>
				<input type="hidden" name="ID" value="<?php echo $ID ?> ">
				<div class="div"><input type="submit" value="Salvar" class="btn"></div>
			</form>
		</section>
	</main>



	<h1 class="h1">Lista De Aparelhos dessa conta</h1>

<?php  


	


	$sql = "SELECT modeloProduto, entradaProduto, acompProduto, estatos, descProduto, idProduto  FROM produto  WHERE idCliente = '$ID' ORDER BY
  idProduto DESC";

	$pegar = mysqli_query($ir, $sql);

	WHILE ($registro = mysqli_fetch_array($pegar)) { 


		$modelo = $registro['modeloProduto'];
		$data = $registro['entradaProduto'];
		$acomp = $registro['acompProduto'];
		$estatos = $registro['estatos'];
		$des = $registro['descProduto'];
		$dia = date('d-m-Y', strtotime($data));
		$hora = date('h:i:s', strtotime($data));
		$local = estatos($estatos);
		$ID2 = $registro['idProduto'];

		

$ID2 = crip($ID2);
?>



<main class="main">
	<section class="section">
		<div class="div">
			
				<label for="">Modelo: <?php echo $modelo ?> </label>
				<label for="">Acompanhamento do Produto: <?php echo $acomp ?> </label>
				<label for="">Data de Entrada: <?php echo $dia ?> </label>
				<label for="">Horas: <?php echo $hora ?> </label>
				<label for="">Local: <?php echo $local ?> </label>
				
				<form action="registros.php" method="post" class="form">
					<input type="hidden" name="IDproduto" value="<?php echo $ID2 ?>" class="input">
					<?php  
					if ($local != 'Aguardando Orçamento') {
						echo '<div class = "div"><input type="submit" name="" value="Mais informações" class = "btn"></div>';
					}
					?>
				</form>

		
		</div>
	</section>
</main>


<?php 
	}

?>

</body>
</html>