<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="rafaStyle.css">
	<link rel="stylesheet" href="style1.css">
	<title>Cadastro de serviço</title>
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
</head>
<?php 
	session_start();
	if (isset($_SESSION['nome']) == false || isset($_SESSION['poder']) == false) 
	{
	session_unset();
	session_destroy();
	die(header('location:validar.php'));	
	} 

 ?>
<body class="body">

<?php 
	include_once('RodaPe.php');
	REQUIRE_ONCE('conect.php');
	REQUIRE_ONCE('criptografia.php');
	$id = descrip($_GET['produto']);

	$sql= "SELECT modeloProduto, descProduto FROM produto where idProduto = '$id' ";
	$pegar = mysqli_query($ir, $sql);
	while ($registro = mysqli_fetch_array($pegar)){
		$modelo = $registro['modeloProduto'];
		$desc = $registro['descProduto'];
	}

?>
<main class="main">
	<section class="sectionCadS">

				<form  method="post" action="#">
					<div class="divLabel">
						<label class="labelCC label">Modelo na Mesa:</label>
						<label class="labelCCresp"><?php echo $modelo; ?></label>
					</div>
					<div class="divLabel">
						<label class="labelCC label">Descrição do Problema:</label>
						<label class="labelCCresp"><?php echo $desc; ?></label>
					</div>
					<div class="divLabel">
						<label for="tabelas" class="labelCC label">Quantidade de Problemas</label>
						<input type="number" name="tabelas"  min="0" value="1" onkeypress="$(this).mask('00')" class="labelCC label labelNumb">
					</div>
					<input type='hidden' value='<?php echo crip($id) ?>' name='IDproduto'>
					<input type="submit" value="Adicionar" class="btn">
				</form>



<?php  
$tabela = isset($_POST['tabelas']) ? $_POST['tabelas'] : false;
if ($tabela == '' || $tabela == 0 || $tabela > 20) {
	echo '<h3>Digite um valor valido</h3>';
	die();
}
$telas = $tabela ;
$telas = $telas +1;
echo "<section class='sectionCad'>";
echo "<form action='savServico.php' method='post' class= 'form formTeste'>";

for ($i=1; $i < $telas; $i++) { 

	echo "
<section class='sectionCD'>
<div class = 'div'>
<label class = 'label'>Quantidade</label> 
<input class='input' type='number' name='tab$i' onkeypress=$(this).mask('00') required> 
<label class = 'label'>Descrição</label> 
<textarea class='input' type= 'text' name='des$i'> </textarea>
<label class = 'label'>Preço</label> 
<input class='input' name='pre$i' onkeypress=$(this).mask('0000.00') required>
<input type='hidden' value='$i' name='rep'><br>
</div>
</section>


	";
	
	
}
$pass = descrip($_POST['IDproduto']);

?>
</section>
<section class="section">
<div class="div">
	
		<label for="dias" class="label"> Previsão:</label>
			<select name="dias" class="input labelCC">
			<option value="1">1 dias</option>
			<option value="2">2 dias</option>
			<option value="3">3 dias</option>
			<option value="4">4 dias</option>
			<option value="5">5 dias</option>
			<option value="6">6 dias</option>
			<option value="7">7 dias</option>
			<option value="14">2 semanas</option>
			</select>
		<label for="descricao" class="label">Descrição</label>
		<input type="text" name="descricao" class="input labelCC">
		<label for="relatorio" class="label">Relatório</label>
		<input type="text" name="relatorio" class="input labelCC">
		<label for="teste" class="lael">Digite 10 para confirmar</label>
		<input type="number" class="input labelCC" placeholder="DIGITE 10" required>
		<input type='hidden' value='<?php echo crip($id); ?>' name='pass'>
		<input type='submit' value='Confirmar' class="btn">
			
</div>

</section>		
		</form>
		
	</div>

</main>
</body>
</html>