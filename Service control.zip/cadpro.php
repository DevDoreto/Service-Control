	<?php  
	error_reporting(0);
	session_start();
	if (isset($_SESSION['nome']) == false || isset($_SESSION['poder']) == false) 
	{
	session_unset();
	session_destroy();
	die(header('location:validar.php'));	
	}  
	

		

	if ($_POST['modelo'] == '') {
		
	}
	else { ?>
	<script type="text/javascript">
	window.alert("Cadastro Efetuado com Sucesso!");
	</script>

		<?php  	
	REQUIRE_ONCE('conect.php');

	date_default_timezone_set('America/Sao_Paulo');

	$ID = $_POST['ID'];
	$modelo = $_POST['modelo'];
	$acompanhamentos =$_POST['acompProduto'];
	$data = date("Y-m-d h:i:s" );
	$estatos = "E";
	echo $ID;


	if ($_POST['bateria'] != null) {
		$problemas .= $_POST['bateria'].", ";
	}
	if ($_POST['tela'] != null) {
		$problemas .= $_POST['tela'].", ";
	}
	if ($_POST['carregamento'] != null) {
		$problemas .= $_POST['carregamento'].", ";
	}
	if ($_POST['outros'] != null){
		$problemas .= $_POST['outros'].", ";
	}
	
	$problemas = substr($problemas, 0, -2);
	
	$sql = "INSERT INTO produto (modeloProduto, acompProduto, descProduto, entradaProduto, idCliente, estatos)
	VALUES 	('$modelo', '$acompanhamentos' , '$problemas' , '$data' , '$ID' , '$estatos' )";
	mysqli_query($ir, $sql);


		
		
		header("Refresh:0.2; url=lista.php");

	}
?>