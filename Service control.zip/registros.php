<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="rafaStyle.css">
	<link rel="stylesheet" href="style1.css">
	<title>Document</title>
</head>
<body>
	


<?php  
	REQUIRE_ONCE('criptografia.php');
	REQUIRE_ONCE('conect.php');
	REQUIRE('funcoes/funcoes.php');
	include('RodaPe.php');

	$ID = descrip($_POST['IDproduto']);
	$sql = "SELECT * FROM produto, servico WHERE servico.idProduto = '$ID'";
	$idBack = $_POST['IDproduto'];
	$pegar = mysqli_query($ir, $sql);

	$registro = mysqli_fetch_array($pegar);
 		


 	$modelo = $registro['modeloProduto'];
 	$data = $registro['entradaProduto'];
 	$acomp = $registro['acompProduto'];
 	$estatos = $registro['estatos'];
 	$desc = $registro['descProduto'];
 	$orca = $registro['orcamento'];
 	$tecnico = $registro['tecnico'];
 	$dataEntrada = $registro['entrada'];
 	$diaE = date(' d-m-Y h:i:s', strtotime($data));
 	$local = estatos($estatos);

	 ?>

<br>
<br>
<main class="main">
	<section class="section">
		<div class="div">
		<div class="divLabel">
					<label class="labelCC label">Modelo: </label>
					<label class="labelCCresp"><?php echo $modelo;  ?></label>
				</div>
				<div class="divLabel">
					<label class="labelCC label">Data de entrada: </label>
					<label class="labelCCresp"><?php echo $diaE;  ?></label>
				</div>
				<div class="divLabel">
					<label class="labelCC label">Acompanhamento: </label>
					<label class="labelCCresp"><?php echo $acomp;  ?></label>
				</div>
				<div class="divLabel">
					<label class="labelCC label">Lugar: </label>
					<label class="labelCCresp"><?php echo $local;  ?></label>
				</div>
				<div class="divLabel">
					<label class="labelCC label">Descrição: </label>
					<label class="labelCCresp"><?php echo $desc;  ?></label>
				</div>
				<div class="divLabel">
					<label class="labelCC label">Orçamento: </label>
					<label class="labelCCresp"><?php echo $orca;  ?></label>
				</div>
				<div class="divLabel">
					<label class="labelCC label">Tecnico: </label>
					<label class="labelCCresp"><?php echo $tecnico;  ?></label>
				</div>
				<form action="lista.php" class="form" method="get">
					<div class="div">
						
						<input type="submit" value="Voltar ao Inicio" class="btn">
						
					</div>
				</form>

		</div>
	</section>
</main>


</body>
</html>