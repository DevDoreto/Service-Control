<?php 
	date_default_timezone_set('America/Sao_Paulo'); 
		 
	session_start();
	if (isset($_SESSION['nome']) == false || isset($_SESSION['poder']) == false) 
	{
			session_unset();
			session_destroy();
			die(header('location:validar.php'));	
	}
	

	REQUIRE_ONCE('conect.php');

	$id = $_POST['IDproduto'];
	$nome = $_POST['nomeRetirada'];
	$dataHora = date('Y-m-d H:i:s');
	$sql= "UPDATE produto SET estatos = 'X' WHERE produto.idProduto = '$id' ";
	mysqli_query($ir, $sql);
 
	$sqlI = "INSERT INTO final (idProduto, nomeRetira, dataSaida) VALUES ('$id', '$nome', '$dataHora')";
	mysqli_query($ir, $sqlI);	
?>
<script> window.alert("Finalizado com Sucesso");</script>
<?php header("Refresh:0.5; url=retirada.php"); ?>
