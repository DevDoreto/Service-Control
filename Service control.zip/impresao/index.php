<?php  

 require('conect.php');

	$sql= "SELECT cliente.nomeCliente, cliente.emailCliente, cliente.telCliente, cliente.cpfCliente, cliente.endCliente FROM cliente, produto  where idProduto = '$id'  ";
	$pegar = mysqli_query($ir, $sql);

	$registro = mysqli_fetch_array($pegar);
		$cliente = $registro['nomeCliente'];
		$email = $registro['emailCliente'];
		$telefone = $registro['telCliente'];
		$cpf = $registro['cpfCliente'];
		$end = $registro['endCliente'];
	
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
<link rel="stylesheet" type="text/css" href="impresao\imprimir.css">
</head>
<body>
 <img src="impresao\rodape.jpg" class="rodape">
 <h2>Ordem de Serviço/Orçamento Prévio</h2>
 <hr>
 <h2>EMISSOR CUPOM NÃO FISCAL</h2>
 <hr>
 	
<h2>Atendentes</h2>
<div>Nome Tecnico: <?php echo  $_SESSION['nome']; ?> </div>

<hr>
<h2>Informações Cliente</h2>
<div>Data: <?php echo $dia ;?>  </div>
<div>Horas: <?php echo $horas ;?> </div>
<div>Nome: <?php echo $cliente ; ?> </div>
<div>Endereço: <?php echo $end ; ?> </div>
<div>Telefone: <?php echo $telefone ; ?></div>



<hr>
<h2 class="hidden">Análise: </h2>
<div>Acompanhamentos: </div><br>
<div>Problemas: </div>

<h2><img src="impresao\cell.png" class="cell">

</h2><br><br>

<div>Senha:</div><br>
<hr>
<table class="tabela">
<tr class="tab2">
	<th colspan="4" class="tab1">Serviços</th>
</tr>
<tr>
	<td >QTD:</td>
	<td >Descrição</td>
	<td >Uni R$:</td>
	<td >Total R$:</td>
</tr>


<?php 

	$arrayQuant = explode(' ', $quant);
	$arrayDesc = explode('/',$desc);
	$arrayPre = explode(' ', $preco);
	$contar = count($arrayQuant);
	print_r($arrayDesc); 
	for ($i=0; $i < $contar-1 ; $i++) { 

		
?>

<tr>
	<td ><?php echo $arrayQuant[$i]; ?></td>
	<td ><?php echo $arrayDesc[$i]; ?></td>
	<td ><?php echo $arrayPre[$i].',00' ; ?></td>
	<td ><?php echo $arrayPre[$i]*$arrayQuant[$i].',00' ; ?></td>
</tr>
<?php
}
?>


<tr class="tab2">
	<th colspan="4">Total R$: <?php echo $valor.',00' ?></th>
</tr>
</table>
<hr>


<div><b>Atenção.</b> <br>
A empresa BETTOCELL não se responsabiliza pela procedência dos aparelhos contidos nessa ordem de serviço, sendo esta responsabilidade do cliente acima citado. Ficando ciente que o prazo máximo para retirada do aparelho será de 90 dias corridos, excedendo esse prazo a empresa BETTOCELL estará autorizada a venda do mesmo, para suprir os gastos de manutenção, conforme LEI 4131/06 de 09/62. A responsabilidade exclusiva de armazenamento de arquivos, chip, cartão de memória e capa, será do cliente e não da empresa BETTOCELL. Em casos de reparo(s) no(s) acabamento(s) da(s) peça(s) original/originais, do aparelho (frontal), o cliente ficará ciente dos riscos da manutenção, podendo caso a peça não funcione corretamente, a substituição por completa da mesma, sendo cobrado do cliente. O valor poderá sofrer alterações dependendo do diagnóstico técnico.
</div><br>
<hr>
 <div>
 	<b>A garantia.</b><br>
 	 será de 90 dias sob peças substituídas ou reparo pago pelos clientes. A garantia não cobre peça danificada, prazo excedido, lacre violado, contato com umidade ou reclamação de serviços não efetuados. Aos aparelhos retirados da assistência pelo cliente, antes do tempo hábil para testes a responsabilidade será exclusivamente do cliente. Garantia não se estende para películas e acessórios.
 </div>
</body>
</html>