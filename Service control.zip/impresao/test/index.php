<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<style type="text/css">
	

.adds{
	background-color: blue;
}



</style>
<body>
<form  method="post" action="#">
<input type="number" name="tabelas"  min="0">
<input type="submit" value="Adicionar">
</form>

<?php  

$telas = $_POST['tabelas'];
$telas = $telas +1;
echo "<form method='post' action='#'>";
for ($i=1; $i < $telas; $i++) { 
	
	echo "painel$i -- Quantidade <input class='adds' type='text' name='tab$i'> 
		descrição <input class='adds' type= 'text' name='des$i'>
		preço <input class='adds' type= 'text' name='pre$i'>
		<input type='hidden' value='$i' name='rep'><br>";
}
if ($telas != '') {
	echo "<input type='submit' value='Salvar'>";
}

echo "</form>";
$rep = $_POST['rep'];
$n = 0;
while ($n < $rep) {
	$n++;
	if ($_POST["tab$n"] != '') {
		$quant .= $_POST["tab$n"].' '; 
	}
}
echo $quant;

?>
</body>
</html>