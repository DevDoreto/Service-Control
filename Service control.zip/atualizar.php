<?php  

		session_start();
	if (isset($_SESSION['nome']) == false || isset($_SESSION['poder']) == false) 
	{
			session_unset();
			session_destroy();
			die(header('location:validar.php'));	
	}  
	


$nome = $_POST['nome'];
$email = $_POST['email'];
$tell1 = $_POST['tell1'];
$tell2 = $_POST['tell2'];
$cpf = $_POST['cpf'];
$endereco = $_POST['endereco'];
$cep = $_POST['cep'];

$cpf = str_replace("." , "" , $cpf );
	$cpf = str_replace("-","",$cpf);


REQUIRE_ONCE('conect.php');
$sql = "UPDATE cliente SET  nomeCliente = '$nome', emailCliente = '$email', telCliente = '$tell1', tel2Cliente = '$tell2', cpfCliente = '$cpf', endCliente = '$endereco', 	cepCliente = '$cep' WHERE cpfCliente = '$cpf'";
mysqli_query($ir, $sql);



header("Refresh:0.1; url=cadastroClientes.php")

?>
<script type="text/javascript">
	window.alert("Cliente atualizado com Sucesso...");
</script>