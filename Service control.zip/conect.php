
<?php
$servidor='localhost';
$usuario='root';
$senha='';
$bd='projecttcc';
$ir= new mysqli($servidor,$usuario,$senha,$bd);
mysqli_set_charset($ir,"utf8");
if ($ir->connect_error){
	die("Erro de conexão ( $mysqli->connect_errno )$mysqli->connect_error");
}
?>