<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="rodape.css">
	<title></title>
	<style type="text/css">
		
	</style>
</head>
<body>

	<header class="headerRP">
		<a href="lista.php" >
			<img src="home.png" alt="Voltar Lista" class="imagemRP">
		</a>
	<form action="lista.php" method="get" class="formRP">
			<input type="text" name="nome" placeholder="PROCURAR CLIENTE" class="inputRP" required>
			<input type="submit" value="🔍" class="lupaRP">
	</form>
	
		<a href="sair.php">
			<img src="logout.png" alt="SAIR" class="imagemRP">
		</a>
	</header>


</body>
</html>