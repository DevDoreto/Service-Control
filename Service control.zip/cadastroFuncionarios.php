<!DOCTYPE html>
<html lang="pt-br">
<?php
  	session_start();
	if (isset($_SESSION['nome']) == false || isset($_SESSION['poder']) == false) 
	{
	session_unset();
	session_destroy();
	die(header('location:validar.php'));	
	}  
	
?>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="rafaStyle.css">
	<link rel="stylesheet" href="style1.css">
	<title>Cadastros de Funcionarios</title>

<?php 
include_once('RodaPe.php');
require_once('conect.php');

?>

</head>
<body class="body">
	<div class="divH1">
		<h1 class="h1">CADASTRAR FUNCIONARIOS</h1>
	</div>	
	<main class="main">
		<section class="section">
			<div class="div">
				<form action="salve.php" method="post" class="form">
					<div class="div">
						<label for="nome" class="label">Primeiro Nome: </label>
						<input type="text" name="nome" placeholder="Primeiro nome" class="input" required>
					
					
						<label for="login" class="label">Login: </label>
						<input type="text" name="login" placeholder="Login" class="input" required>
				
					
						<label for="senha" class="label">Senha: </label>
						<input type="text" name="senha" placeholder="Senha" class="input" required>
					</div>
						
					<div class="div"> 
						<label for="poder" class="label">Cargo: </label>
							<label for="btn" class="label">
								<select name="poder" class="select" required>
									<option value="A">Administrador</option>
									<option value="T">Tecnico</option>
									<option value="R">Recepção</option>
								</select>
							</label>
						
						<input type="submit" value="Salvar" name="btn" class="btn">
					</div>
				</form>
			</div>
		</section>
	</main>

	<div class="divH1">
		<h1 class="h1">DESATIVAR OU ATIVAR CONTAS</h1>
	</div>
	
	
	<main class="main">
		<section class="section">
			<div class="div">
				<form action="#" method="post" class="form">

					<div class="div">
						<label for="pesquisa" class="label ">Deixe em branco para aparecer todos</label>
					</div>
					<input type="text" name="pesquisa" placeholder="Digite o nome do funcionario" class="input">
					<input type="submit" value="🔍" class="btn">
				</form>
			</div>
		</section>
	</main>

	<?php
	$validar =2;
		REQUIRE_ONCE('conect.php');
	
	if (isset($_POST['pesquisa'])== true) {
		$info = addslashes(trim($_POST['pesquisa']));
	};

	if(isset($info) == true){
	
	$sql="SELECT primeiroNome, 	login, idFuncionario, estatos   FROM funcionarios where primeiroNome LIKE '%$info%' ";
	$pegar = mysqli_query($ir, $sql);
	
	$validar = 0;
	while ($registro = mysqli_fetch_array($pegar)) { 
	$nome = $registro["primeiroNome"];
	$login = $registro["login"];
	$ID = $registro["idFuncionario"];
	$statos = $registro["estatos"];
	$validar = 1;
	if ($statos == 1) {
		$ativo = "Ativo";
	}
	else {
		$ativo = "Desativado";
	}
	?>
		
	<main class="main">
		<section class="section">
			<div class="div">
				<form method="post" action="editarFuncionarios.php" class="form">
				<label class="label">Nome: <?php echo $nome;  ?></label><br>
				<label class="label">Login: <?php echo $login; ?></label><br>
				<label class="label">Estatos: <?php echo $ativo; ?></label>
				<input type="hidden" name="estatos" value="<?php echo $statos;  ?>" class="input">
				<input type="hidden" name="ID" value="<?php echo $ID;  ?>" class="input">
				<input type="submit" value="Alterar" class="input">
				</form>
			</div>
		</section>
	</main>
	
	

	<?php  
}}

if (isset($validar) != 1 || $validar != 2 ){
?>


	<div class="boxAlert">
		<h1 class="alert">FUNCIONARIO NÃO ENCONTRADO</h1>
			
	</div>
	
<?php
}

?>
</body>
</html>