<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="rafaStyle.css">
	<link rel="stylesheet" href="style1.css">
	<title>Manutenção</title>
	<?php include_once('RodaPe.php');?>
	<?php
		session_start();
	if (isset($_SESSION['nome']) == false || isset($_SESSION['poder']) == false) 
	{
			session_unset();
			session_destroy();
			die(header('location:validar.php'));	
	}  ?>
</head>
<body class="body">
	<div class="menuServ">
		<a href="servico.php" class="linkServ">Aguardando orçamento</a>
		<a href="confirmados.php" class="linkServ">Aguardando Confirmação</a>
		<a href="manutencao.php" class="linkServ">Aguardando Manutenção</a>
	</div>
	<?php 
	REQUIRE_ONCE('conect.php');	

	
	$sql= "SELECT * FROM produto, servico WHERE produto.estatos = 'M' AND produto.idProduto = servico.idProduto";
	$pegar = mysqli_query($ir, $sql);
	$validar = 0;
	while ($registro = mysqli_fetch_array($pegar)){
		$id = $registro['idProduto'];
		$modelo = $registro['modeloProduto'];
		$desc = $registro['descProduto'];
		$data = $registro['entrada'];
		$dia = date('d-m-Y', strtotime($data));
		$previsao = $registro['previsao'];
		$previsao = date('d-m-Y', strtotime($dia.  '+'.$previsao.' days' ));
		$orca = $registro['orcamento'];
		$pecas = $registro['pecas'];
		$tec = $registro['tecnico'];
		$rela = $registro['relatorio'];
		$validar = 2;
		
		
		
		?>
<main class="main">
	<section class="secConf section">
		<div class="div">
			

				<div class="divLabel">
					<label class="labelCC label">Modelo: </label>
					<label class="labelCCresp"><?php echo $modelo;  ?></label>
				</div>
				<div class="divLabel">
					<label class="labelCC label">Data de entrada:</label>
					<label class="labelCCresp"><?php echo $dia;  ?></label>
				</div>
				<div class="divLabel">
					<label class="labelCC label">Previsão de Saida:</label> 
					<label class="labelCCresp "><?php echo $previsao; ?></label>
				</div>
				<div class="divLabel">
					<label class="labelCC label">Problemas:</label> 
					<label class="labelCCresp "><?php echo $desc; ?></label>
				</div>
				<div class="divLabel">
					<label class="labelCC label">Orçamento:</label> 
					<label class="labelCCresp "><?php echo $orca; ?></label>
				</div>
				<div class="divLabel">
					<label class="labelCC label">Peças:</label> 
					<label class="labelCCresp "><?php echo $pecas; ?></label>
				</div>
				<div class="divLabel">
					<label class="labelCC label">Relatorio do Tecnico:</label> 
					<label class="labelCCresp labelCC"><?php echo $rela; ?></label>
				</div>
				<div class="divLabel">
					<label class="labelCC label">Tecnico:</label> 
					<label class="labelCCresp "><?php echo $tec; ?></label>
				</div>


<form action="final.php" method="post">
	<input type="hidden" name="IDproduto" value="<?php echo $id ?>">
	<input type="submit" name="" value="Feito o Servico" class="btn">
</form>
</div>
</section>
</main>






<?php } ?>

<?php 
if ($validar == 0) {
	?>

	<div class="boxAlert">
		<h1 class="alert">NÃO EXISTE REGISTROS</h1>
		<a href="index.php"><button class="btn">VOLTAR PARA O INICIO</button></a>
	</div>

	<?php
}
?>


</body>
</html>