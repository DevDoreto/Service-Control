	<?php  
	session_start();
	if (isset($_SESSION['nome']) == false || isset($_SESSION['poder']) == false) 
	{
	session_unset();
	session_destroy();
	die(header('location:validar.php'));	
	} 
	
	REQUIRE_ONCE('conect.php');

	if ($_POST['cpf'] == '') {
		
	}
	else { ?>
	<script type="text/javascript">
	window.alert("Cadastro Efetuado com Sucesso!");
	</script>
	<?php 
	$nome = $_POST['name'];
	$email = $_POST['email'];
	$tell1 = $_POST['tellCliente1'];
	$tell2 = $_POST['tellCliente2'];
	$cpf = $_POST['cpf'];
	$cep = $_POST['cep'];
	$endereco = $_POST['endereco'];


		$sql =  "INSERT INTO cliente (nomeCliente , emailCliente , telCliente , tel2Cliente , cpfCliente , endCliente) 
		VALUES ('$nome' , '$email' , '$tell1' , '$tell2' , '$cpf' , '$endereco')";
	mysqli_query($ir, $sql);
}


	header('location: cadastroClientes.php');
 

	?>