<!DOCTYPE html>
<html>
<head>
	<?php 
	REQUIRE_ONCE('criptografia.php');
	REQUIRE_ONCE('conect.php');
	include_once('RodaPe.php'); 
	?>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="rafaStyle.css">
	<link rel="stylesheet" href="style1.css">
	<title>Lista</title>
	<?php 

	session_start();
	if (isset($_SESSION['nome']) == false || isset($_SESSION['poder']) == false) 
	{
			session_unset();
			session_destroy();
			die(header('location:validar.php'));	
	}
	?>


</head>
<body class="body">
<?php
 

	

	$info = isset($_GET['nome']) ? trim(addslashes($_GET['nome'])) : false ;
	if ($info) {

	$sql="SELECT idCliente, nomeCliente, telCliente, cpfCliente, cepCliente FROM cliente where cpfCliente LIKE '%$info%' OR nomeCliente LIKE '%$info%' ORDER BY
  idCliente DESC ";
	$pegar = mysqli_query($ir, $sql);



	while ($registro = mysqli_fetch_array($pegar)) { 

	$nome = $registro["nomeCliente"];
	$telefone = $registro["telCliente"];
	$cpf = $registro["cpfCliente"];
	$cep = $registro["cepCliente"];
	$ID = $registro["idCliente"];
	$ID = crip($ID);
	?>
		<main class="main">
			<section class="section">
				<form method="get" action="cadastroProdutos.php" class="form">
				<div class="divLabel">
					<label class="labelCC label">Nome:</label>
					<label class="labelCCresp"><?php echo $nome; ?></label>
				</div>
				<div class="divLabel">
					<label class="labelCC label">Telefone:</label>
					<label class="labelCCresp"><?php echo $telefone; ?></label>
				</div>
				<div class="divLabel">
					<label class="labelCC label">CPF:</label>
					<label class="labelCCresp"><?php echo $cpf; ?></label>
				</div>
				<div class="divLabel">
					<label class="labelCC label">CEP:</label>
					<label class="labelCCresp"><?php echo $cep; ?></label>
				</div>
			
				<input type="submit" value="REGISTRAR PRODUTO" class="btn">
				<input type="hidden" name="comanda" value="<?php echo $ID;  ?>">
					
					</form>
			</section>
		</main>
		
	<?php  
}}
?>

<section class="sectLista">
	<div class="container">
	  <div class="card">
		<label class="title"><a href="cadastroClientes.php" class="linkLista">CLIENTES CADASTRADOS</a></label>
		<div class="num">
			<?php 
			$sql2 = "SELECT COUNT(*) AS total FROM cliente";
			$resultado = mysqli_query($ir, $sql2);
			while ($valor = mysqli_fetch_array($resultado)) {
				?>
				</br>
				<label class="busc"> <?php echo $valor["total"]; ?> </label>	 <?php 
			}

			?>
		</div>
	  </div>
	  <div class="card">
		<label class="title"><a href="servico.php" class="linkLista"> PRODUTOS </a></label>
		<div class="num">
		<?php 
			$sql2 = "SELECT COUNT(*) AS total FROM produto WHERE estatos <> 'X' AND estatos <> 'F'";
			$resultado = mysqli_query($ir, $sql2);
			while ($valor = mysqli_fetch_array($resultado)) {
				 ?>
				</br>
				<label class="busc"> <?php echo $valor["total"]; ?> </label>	 <?php 
			}

			?>
		</div>
	  </div>
	  <div class="card">
		<label class="title"><a href="retirada.php" class="linkLista">AGUARDANDO RETIRADA</a></label>
		<div class="num">
		<?php 
			$sql2 = "SELECT COUNT(*) AS total FROM produto WHERE estatos = 'F' ";
			$resultado = mysqli_query($ir, $sql2);
			while ($valor = mysqli_fetch_array($resultado)) {
				 ?>
				</br>
				<label class="busc"> <?php echo $valor["total"]; ?> </label>	 <?php 
			}

			?>
		</div>
	  </div>

	  <div class="card">
		<label class="title"><a href="cadastroFuncionarios.php" class="linkLista">FUNCIONARIOS CADASTRADOS</a></label>
		<div class="num">
		<?php 
			$sql2 = "SELECT COUNT(*) AS total FROM funcionarios WHERE estatos = 1 ";
			$resultado = mysqli_query($ir, $sql2);
			while ($valor = mysqli_fetch_array($resultado)) {
				 ?>
				</br>
				<label class="busc"> <?php echo $valor["total"]; ?> </label>	 <?php 
			}

			?>
		</div>
	  </div>
	</div>
</section>
</body>
</html>