<?php  

function estatos($estatos){

if ($estatos == 'E') {
	$local = "Aguardando Orçamento";
}
elseif ($estatos == 'A') {
	$local = "Esperando confirmação de Orçamento";	
}
elseif ($estatos == 'M') {
	$local = "Em Manutenção ou Aguardando Pagamento";
}
elseif ($estatos == 'X'){
	$local = "Finalizado";
}
else{
	$local = "ERRO localização não registrada";
}
return $local;
}

?>