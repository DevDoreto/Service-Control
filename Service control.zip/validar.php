<?php  
REQUIRE_ONCE('conect.php');

	if (isset($_POST['login']) != null && isset($_POST['senha']) != null ) 
	{
		$login = addslashes(trim($_POST['login']));
		$senha = addslashes(trim($_POST['senha']));

		$sql = "SELECT primeiroNome, login, senha, poder FROM funcionarios WHERE login = '$login' AND senha = '$senha' AND estatos = 1 ";
		$pegar = mysqli_query($ir, $sql);
		$erro = 0;

		$registro = mysqli_fetch_array($pegar); { 
			$erro =1;
			$nome = $registro['primeiroNome'];
			$poder = $registro['poder'];

		}
		if ($erro == 1)
		{
		session_start();
		$_SESSION['nome'] = $nome;
		$_SESSION['poder']	= $poder;	
		header('location:lista.php');
		}
		else 
		{
			?>
			<h1 style=" color: red; font-size: 30px;">ERROR DE LOGIN TENTE NOVAMENTE... REDIRECIONAMENTO EM 5 SEGUNDOS!</h1>
			<?php
			die(header("Refresh:5; url=index.php"));
		}
	}
	else 
	{
			?>
		<h1 style=" color: red; font-size: 30px;">ERROR DE LOGIN TENTE NOVAMENTE... REDIRECIONAMENTO EM 5 SEGUNDOS!</h1>
		<?php
		die(header("Refresh:5; url=index.php"));	
	}

?>